# tharos-pytools

This package contains cool functions in order to better manage Python projects.
For now, it only contains functions to ensure multithreading on a function, with respect to memory.
