'Init paths'
from .multithreading import futures_collector, limit_memory
from .matplotlib_tools import get_palette, get_palette_from_list
from .overloading import overload
